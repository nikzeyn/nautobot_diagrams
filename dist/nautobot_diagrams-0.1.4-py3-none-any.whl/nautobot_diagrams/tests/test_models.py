from nautobot.utilities.testing import TestCase

from nautobot_diagrams import models