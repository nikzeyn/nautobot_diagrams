"""REST API for NextBox-UI Plugin"""
