# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nautobot_diagrams',
 'nautobot_diagrams.api',
 'nautobot_diagrams.migrations',
 'nautobot_diagrams.tests']

package_data = \
{'': ['*'],
 'nautobot_diagrams': ['static/nautobot_diagrams/*',
                       'static/nautobot_diagrams/img/*',
                       'static/nautobot_diagrams/jquery-ui-1.12.1/*',
                       'static/nautobot_diagrams/jquery/*',
                       'static/nautobot_diagrams/next_sources/*',
                       'static/nautobot_diagrams/next_sources/css/*',
                       'static/nautobot_diagrams/next_sources/doc/*',
                       'static/nautobot_diagrams/next_sources/doc/assets/*',
                       'static/nautobot_diagrams/next_sources/doc/assets/css/*',
                       'static/nautobot_diagrams/next_sources/doc/assets/img/*',
                       'static/nautobot_diagrams/next_sources/doc/assets/js/*',
                       'static/nautobot_diagrams/next_sources/doc/assets/vendor/prettify/*',
                       'static/nautobot_diagrams/next_sources/doc/classes/*',
                       'static/nautobot_diagrams/next_sources/doc/files/*',
                       'static/nautobot_diagrams/next_sources/doc/modules/*',
                       'static/nautobot_diagrams/next_sources/fonts/*',
                       'static/nautobot_diagrams/next_sources/js/*',
                       'templates/nautobot_diagrams/*']}

setup_kwargs = {
    'name': 'nautobot-diagrams',
    'version': '0.1.4',
    'description': 'Diagrams Plugin for Nautobot',
    'long_description': None,
    'author': 'Nik Zeynalov',
    'author_email': 'nik.zeynalov@originenergy.com.au',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
